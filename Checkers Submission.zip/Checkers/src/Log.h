/*
 * Log.h
 *
 *  Created on: Mar 3, 2021
 *      Author: radcl
 */

#ifndef LOG_H_
#define LOG_H_

#include "LLMove.h"
#include "Board.h"
#include <stdio.h>
#include <iostream>
#include <fstream>
using namespace std;

class Log {
public:
	Log();
	virtual ~Log();
};

#endif /* LOG_H_ */
