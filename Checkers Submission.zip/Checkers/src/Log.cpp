/*
 * Log.cpp
 *
 *  Created on: Mar 3, 2021
 *      Author: radcl
 */

#include "Log.h"

Log::Log() {
	// TODO Auto-generated constructor stub

}

Log::~Log() {
	// TODO Auto-generated destructor stub
}

